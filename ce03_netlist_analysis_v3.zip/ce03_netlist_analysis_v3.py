#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MIL-STD-461C CE03 calculation from an LTspice ExpressPCB .net file (v3).

This script is tailored to the uploaded EMI-filter schematic, but it reads the
component topology and values from the .net file.  The .asc file is used to
read coupled-inductor K statements and each inductor's Rser where available.

Outputs
-------
1. ce03_full_harmonics.csv
   Exact Fourier-series lines of the 125 kHz periodic PULSE source
   (125 kHz, 250 kHz, ... 50 MHz; 400 harmonics).
2. ce03_continuous_envelope.csv
   10 kHz to 50 MHz continuous envelope.  Non-harmonic frequencies are a
   visualization/reference only; an exactly periodic source has spectral lines
   only at integer multiples of 125 kHz.
3. ce03_full_frequency.png
   CE03 limit, continuous envelope, and all exact harmonic points.
4. r18_power_summary.csv
   R18 power split into 400 Hz and switching-harmonic components.

Usage example
-------------
1) VS Code の実行ボタン:
   引数なしで実行すると、netファイル選択ダイアログが開きます。
   同名のascファイルがあれば自動的に読み込みます。

2) ターミナル:
   python ce03_netlist_analysis_v3.py \
       "461C_FILTER_20260719(2).net" \
       --asc "461C_FILTER_20260719(2).asc" \
       --outdir ce03_output

Required packages: numpy, pandas, matplotlib
"""

from __future__ import annotations

import argparse
import ast
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
import pandas as pd


# -----------------------------------------------------------------------------
# User settings for the present design
# -----------------------------------------------------------------------------
AC_RMS_V = 115.0
AC_FREQUENCY_HZ = 400.0
POUT_W = 250.0
PF = 0.90
AF = 0.85
DF = 0.85

FSW_HZ = 125e3
IDM_PP_A = 1.0
ICM_PP_A = 20e-3
RISE_TIME_S = 50e-9
FALL_TIME_S = 50e-9
# For a symmetric bipolar PULSE, LTspice's PW excludes the rise/fall times.
PULSE_PERIOD_S = 1.0 / FSW_HZ
PULSE_HIGH_TIME_S = PULSE_PERIOD_S / 2.0 - RISE_TIME_S

FREQ_MIN_HZ = 10e3
CE03_MIN_HZ = 15e3
FREQ_MAX_HZ = 50e6
CONTINUOUS_POINTS_PER_DECADE = 200

# Current source amplitude definitions used in the uploaded schematic:
# I1: +/- Idm_pp/2  -> total 1 A p-p differential source
# I2, I3: +/- Icm_pp/4 each -> each source is 10 mA p-p when Icm_pp=20 mA
IDM_HALF_AMPLITUDE_A = IDM_PP_A / 2.0
ICM_EACH_HALF_AMPLITUDE_A = ICM_PP_A / 4.0

# Fallbacks if the ASC file is unavailable.
DEFAULT_COUPLINGS = [("L8", "L9", 0.998), ("L24", "L25", 0.998)]
DEFAULT_INDUCTOR_RSER_OHM = 1e-3


# -----------------------------------------------------------------------------
# Parsing
# -----------------------------------------------------------------------------
SPICE_SUFFIX = {
    "": 1.0,
    "t": 1e12,
    "g": 1e9,
    "meg": 1e6,
    "k": 1e3,
    "m": 1e-3,
    "u": 1e-6,
    "n": 1e-9,
    "p": 1e-12,
    "f": 1e-15,
}


def spice_number(text: str) -> float:
    """Convert an LTspice number such as 4.7m, 0.33u, 1.8k to float."""
    normalized = text.strip().lower().replace("µ", "u").replace("μ", "u")
    match = re.fullmatch(
        r"([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?)(meg|[tgkmunpf]?)",
        normalized,
    )
    if not match:
        raise ValueError(f"Unsupported SPICE number: {text!r}")
    return float(match.group(1)) * SPICE_SUFFIX[match.group(2)]



# Safe evaluator for LTspice .param expressions.
# Parameter names are handled case-insensitively, as in LTspice.
PARAMETER_FALLBACKS: Dict[str, float] = {
    "acrms": AC_RMS_V,
    "fac": AC_FREQUENCY_HZ,
    "pout": POUT_W,
    "pf": PF,
    "af": AF,
    "df": DF,
    # Present design fallback.  If the ASC contains .param RD18=..., that value
    # is read automatically and replaces this fallback.
    "rd18": 100.0,
}

_SAFE_FUNCTIONS = {
    "sqrt": math.sqrt,
    "abs": abs,
    "min": min,
    "max": max,
    "sin": math.sin,
    "cos": math.cos,
    "tan": math.tan,
    "log": math.log,
    "log10": math.log10,
    "exp": math.exp,
}

_SPICE_LITERAL_RE = re.compile(
    r"(?<![A-Za-z_])([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?)(meg|[tgkmunpf])\b",
    re.IGNORECASE,
)


def _replace_spice_literals(expression: str) -> str:
    """Replace 4.7m, 50n, 125k, etc. by ordinary decimal literals."""
    def repl(match: re.Match[str]) -> str:
        return repr(float(match.group(1)) * SPICE_SUFFIX[match.group(2).lower()])

    return _SPICE_LITERAL_RE.sub(repl, expression)


def evaluate_parameter_expression(expression: str, values: Mapping[str, float]) -> float:
    """Safely evaluate a numeric LTspice parameter expression."""
    text = expression.strip()
    if text.startswith("{") and text.endswith("}"):
        text = text[1:-1].strip()
    text = _replace_spice_literals(text.replace("^", "**"))
    tree = ast.parse(text, mode="eval")
    env = {str(key).lower(): float(value) for key, value in values.items()}

    def visit(node: ast.AST) -> float:
        if isinstance(node, ast.Expression):
            return visit(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return float(node.value)
        if isinstance(node, ast.Name):
            key = node.id.lower()
            if key not in env:
                raise KeyError(node.id)
            return env[key]
        if isinstance(node, ast.UnaryOp):
            operand = visit(node.operand)
            if isinstance(node.op, ast.UAdd):
                return +operand
            if isinstance(node.op, ast.USub):
                return -operand
        if isinstance(node, ast.BinOp):
            left = visit(node.left)
            right = visit(node.right)
            if isinstance(node.op, ast.Add):
                return left + right
            if isinstance(node.op, ast.Sub):
                return left - right
            if isinstance(node.op, ast.Mult):
                return left * right
            if isinstance(node.op, ast.Div):
                return left / right
            if isinstance(node.op, ast.Pow):
                return left**right
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            name = node.func.id.lower()
            if name not in _SAFE_FUNCTIONS:
                raise ValueError(f"Unsupported function in parameter expression: {name}")
            return float(_SAFE_FUNCTIONS[name](*(visit(arg) for arg in node.args)))
        raise ValueError(f"Unsupported parameter expression: {expression!r}")

    return float(visit(tree))


def read_parameter_expressions(paths: Iterable[Optional[Path]]) -> Dict[str, str]:
    """Collect NAME=EXPR assignments from .param directives in NET/ASC files."""
    expressions: Dict[str, str] = {}
    assignment_re = re.compile(r"([A-Za-z_]\w*)\s*=\s*(\{[^}]*\}|[^\s]+)")

    for path in paths:
        if path is None or not path.exists():
            continue
        try:
            lines = path.read_text(encoding="cp932").splitlines()
        except UnicodeDecodeError:
            lines = path.read_text(encoding="utf-8-sig").splitlines()

        for line in lines:
            match = re.search(r"(?:!|^)\s*\.param\s+(.+)$", line, re.IGNORECASE)
            if not match:
                continue
            for assignment in assignment_re.finditer(match.group(1)):
                expressions[assignment.group(1).lower()] = assignment.group(2)

    return expressions


def resolve_parameters(paths: Iterable[Optional[Path]]) -> Dict[str, float]:
    """Resolve all readable .param assignments, including dependent formulas."""
    expressions = read_parameter_expressions(paths)
    values: Dict[str, float] = dict(PARAMETER_FALLBACKS)

    # The present design evaluates the noise with these requested values even
    # if the ASC still contains Idm_pp=0 and Icm_pp=0 for interactive editing.
    values.update({
        "idm_pp": IDM_PP_A,
        "icm_pp": ICM_PP_A,
        "fsw": FSW_HZ,
    })

    unresolved = dict(expressions)
    for _ in range(max(4, len(unresolved) + 2)):
        progress = False
        for name, expression in list(unresolved.items()):
            # Keep the requested analysis overrides for these source settings.
            if name in {"idm_pp", "icm_pp"}:
                unresolved.pop(name)
                continue
            try:
                values[name] = evaluate_parameter_expression(expression, values)
            except KeyError:
                continue
            unresolved.pop(name)
            progress = True
        if not progress:
            break

    # RL is essential and is also available from the design constants.
    pin_w = POUT_W / (PF * AF * DF)
    values.setdefault("pin", pin_w)
    values.setdefault("rl", AC_RMS_V**2 / pin_w)

    if unresolved:
        print("警告: 次の.param式は依存値不足のため未解決です:")
        for name, expression in unresolved.items():
            print(f"  {name} = {expression}")

    return values


@dataclass
class Part:
    name: str
    value_text: str
    p1: str
    p2: str
    value: Optional[float] = None


def parse_expresspcb_netlist(path: Path, parameter_values: Mapping[str, float]) -> List[Part]:
    """Parse the ExpressPCB-format netlist exported by LTspice."""
    lines = path.read_text(encoding="cp932").splitlines()
    raw_parts: List[Tuple[str, str]] = []
    net_names: Dict[int, str] = {}
    connections: List[Tuple[int, int, int]] = []
    mode = ""

    for line in lines:
        if line == '"Part IDs Table"':
            mode = "parts"
            continue
        if line == '"Net Names Table"':
            mode = "nets"
            continue
        if line == '"Net Connections Table"':
            mode = "connections"
            continue
        if not line.strip():
            continue

        if mode == "parts" and line.startswith('"'):
            quoted = re.findall(r'"([^"]*)"', line)
            if len(quoted) >= 2:
                raw_parts.append((quoted[0], quoted[1]))
        elif mode == "nets" and line.startswith('"'):
            match = re.match(r'"([^"]+)"\s+(\d+)', line)
            if match:
                net_names[int(match.group(2))] = match.group(1)
        elif mode == "connections":
            fields = line.split()
            if len(fields) >= 3 and all(item.isdigit() for item in fields[:3]):
                connections.append(tuple(map(int, fields[:3])))

    endpoints: Dict[int, Dict[int, str]] = {
        part_index: {} for part_index in range(1, len(raw_parts) + 1)
    }
    for net_index, part_index, pin_number in connections:
        endpoints[part_index][pin_number] = net_names.get(net_index, f"_N{net_index}")

    parts: List[Part] = []
    for part_index, (name, value_text) in enumerate(raw_parts, start=1):
        p1 = endpoints[part_index].get(1, "0")
        p2 = endpoints[part_index].get(2, "0")
        numeric_value: Optional[float] = None
        if name.startswith(("R", "L", "C")):
            parameter_match = re.fullmatch(r"\{([^}]+)\}", value_text.strip())
            if parameter_match:
                expression = parameter_match.group(1)
                try:
                    numeric_value = evaluate_parameter_expression(expression, parameter_values)
                except KeyError as exc:
                    missing = str(exc).strip("'\"")
                    available = ", ".join(sorted(parameter_values))
                    raise KeyError(
                        f"No value supplied for parameter {missing!r} used by "
                        f"{name}={value_text}. Parsed parameters: {available}"
                    ) from exc
            else:
                numeric_value = spice_number(value_text)
        parts.append(Part(name, value_text, p1, p2, numeric_value))

    return parts


def parse_asc_metadata(path: Optional[Path]) -> Tuple[List[Tuple[str, str, float]], Dict[str, float]]:
    """Read K statements and per-inductor Rser values from an ASC file."""
    if path is None or not path.exists():
        return list(DEFAULT_COUPLINGS), {}

    lines = path.read_text(encoding="cp932").splitlines()
    couplings: List[Tuple[str, str, float]] = []
    inductor_rser: Dict[str, float] = {}

    # Coupling statements, for example: !K2 L24 L25 0.998
    for line in lines:
        match = re.search(r"!K\S*\s+(L\S+)\s+(L\S+)\s+([0-9.eE+-]+)", line)
        if match:
            couplings.append((match.group(1), match.group(2), float(match.group(3))))

    # Parse symbol blocks to associate SpiceLine Rser with InstName.
    current_name: Optional[str] = None
    current_rser: Optional[float] = None

    def flush_symbol() -> None:
        nonlocal current_name, current_rser
        if current_name and current_name.startswith("L") and current_rser is not None:
            inductor_rser[current_name] = current_rser
        current_name = None
        current_rser = None

    for line in lines:
        if line.startswith("SYMBOL ") or line.startswith("TEXT "):
            flush_symbol()
        if line.startswith("SYMATTR InstName "):
            current_name = line.split(maxsplit=2)[2].strip()
        elif line.startswith("SYMATTR SpiceLine "):
            match = re.search(r"Rser=([^\s]+)", line, re.IGNORECASE)
            if match:
                current_rser = spice_number(match.group(1))
    flush_symbol()

    return couplings or list(DEFAULT_COUPLINGS), inductor_rser


# -----------------------------------------------------------------------------
# Modified nodal analysis
# -----------------------------------------------------------------------------
class LinearCircuit:
    def __init__(
        self,
        parts: Sequence[Part],
        couplings: Sequence[Tuple[str, str, float]],
        inductor_rser: Mapping[str, float],
    ) -> None:
        self.parts = list(parts)
        self.by_name = {part.name: part for part in parts}
        self.couplings = list(couplings)
        self.inductor_rser = dict(inductor_rser)
        self.coupled_inductors = {
            name for first, second, _ in couplings for name in (first, second)
        }

        self.voltage_sources = [
            name for name in ("V1", "VPROBE_HOT", "VPROBE_RTN") if name in self.by_name
        ]
        nodes = sorted(
            {
                node
                for part in parts
                for node in (part.p1, part.p2)
                if node != "0"
            }
        )
        self.node_index = {node: index for index, node in enumerate(nodes)}
        branch_names = list(self.voltage_sources)
        for first, second, _ in couplings:
            branch_names.extend([first, second])
        self.branch_index = {
            name: len(nodes) + index for index, name in enumerate(branch_names)
        }
        self.size = len(nodes) + len(branch_names)

    def _stamp_admittance(self, matrix: np.ndarray, n1: str, n2: str, y: complex) -> None:
        if n1 != "0":
            matrix[self.node_index[n1], self.node_index[n1]] += y
        if n2 != "0":
            matrix[self.node_index[n2], self.node_index[n2]] += y
        if n1 != "0" and n2 != "0":
            i1 = self.node_index[n1]
            i2 = self.node_index[n2]
            matrix[i1, i2] -= y
            matrix[i2, i1] -= y

    def _stamp_branch(self, matrix: np.ndarray, n1: str, n2: str, branch: int) -> None:
        # Branch current is positive from pin 1 to pin 2.
        if n1 != "0":
            matrix[self.node_index[n1], branch] += 1.0
            matrix[branch, self.node_index[n1]] += 1.0
        if n2 != "0":
            matrix[self.node_index[n2], branch] -= 1.0
            matrix[branch, self.node_index[n2]] -= 1.0

    def solve(
        self,
        frequency_hz: float,
        current_sources_rms: Optional[Mapping[str, complex]] = None,
        mains_voltage_rms: complex = 0.0,
    ) -> np.ndarray:
        omega = 2.0 * math.pi * frequency_hz
        matrix = np.zeros((self.size, self.size), dtype=complex)
        rhs = np.zeros(self.size, dtype=complex)

        for part in self.parts:
            element_type = part.name[0]
            if element_type == "R":
                assert part.value is not None
                self._stamp_admittance(matrix, part.p1, part.p2, 1.0 / part.value)
            elif element_type == "C":
                assert part.value is not None
                self._stamp_admittance(
                    matrix, part.p1, part.p2, 1j * omega * part.value
                )
            elif element_type == "L" and part.name not in self.coupled_inductors:
                assert part.value is not None
                rser = self.inductor_rser.get(part.name, DEFAULT_INDUCTOR_RSER_OHM)
                impedance = rser + 1j * omega * part.value
                self._stamp_admittance(matrix, part.p1, part.p2, 1.0 / impedance)

        # Independent zero-volt probes and the mains voltage source.
        for source_name in self.voltage_sources:
            part = self.by_name[source_name]
            branch = self.branch_index[source_name]
            self._stamp_branch(matrix, part.p1, part.p2, branch)
            rhs[branch] = mains_voltage_rms if source_name == "V1" else 0.0

        # Coupled inductors are stamped as a 2 x 2 branch-impedance matrix.
        for first_name, second_name, coupling in self.couplings:
            first = self.by_name[first_name]
            second = self.by_name[second_name]
            assert first.value is not None and second.value is not None
            first_branch = self.branch_index[first_name]
            second_branch = self.branch_index[second_name]
            self._stamp_branch(matrix, first.p1, first.p2, first_branch)
            self._stamp_branch(matrix, second.p1, second.p2, second_branch)

            mutual = coupling * math.sqrt(first.value * second.value)
            r1 = self.inductor_rser.get(first_name, DEFAULT_INDUCTOR_RSER_OHM)
            r2 = self.inductor_rser.get(second_name, DEFAULT_INDUCTOR_RSER_OHM)
            matrix[first_branch, first_branch] -= r1 + 1j * omega * first.value
            matrix[second_branch, second_branch] -= r2 + 1j * omega * second.value
            matrix[first_branch, second_branch] -= 1j * omega * mutual
            matrix[second_branch, first_branch] -= 1j * omega * mutual

        # Independent current sources. Positive current flows from pin 1 to pin 2.
        for source_name, source_current in (current_sources_rms or {}).items():
            part = self.by_name[source_name]
            if part.p1 != "0":
                rhs[self.node_index[part.p1]] -= source_current
            if part.p2 != "0":
                rhs[self.node_index[part.p2]] += source_current

        try:
            return np.linalg.solve(matrix, rhs)
        except np.linalg.LinAlgError as exc:
            raise RuntimeError(
                f"Circuit matrix is singular at {frequency_hz:g} Hz. "
                "Check floating nodes and component connections."
            ) from exc

    def branch_current(self, solution: np.ndarray, source_name: str) -> complex:
        return solution[self.branch_index[source_name]]

    def resistor_current(self, solution: np.ndarray, resistor_name: str) -> complex:
        resistor = self.by_name[resistor_name]
        assert resistor.value is not None
        v1 = 0.0 if resistor.p1 == "0" else solution[self.node_index[resistor.p1]]
        v2 = 0.0 if resistor.p2 == "0" else solution[self.node_index[resistor.p2]]
        return (v1 - v2) / resistor.value


# -----------------------------------------------------------------------------
# Source spectrum and CE03 limit
# -----------------------------------------------------------------------------
def _integral_linear_times_exponential(
    start: float,
    stop: float,
    y_start: float,
    y_stop: float,
    angular_frequency: float,
    period: float,
) -> complex:
    """Return (1/T) integral y(t) exp(-j*w*t) dt over one linear segment."""
    if stop <= start:
        return 0j
    slope = (y_stop - y_start) / (stop - start)
    intercept = y_start - slope * start
    s = -1j * angular_frequency

    if abs(angular_frequency) < 1e-30:
        integral = 0.5 * slope * (stop**2 - start**2) + intercept * (stop - start)
        return integral / period

    def antiderivative(time_s: float) -> complex:
        return np.exp(s * time_s) * (
            slope * (time_s / s - 1.0 / s**2) + intercept / s
        )

    return (antiderivative(stop) - antiderivative(start)) / period


def pulse_sine_rms_coefficient(
    frequency_hz: float,
    half_amplitude_a: float,
    period_s: float = PULSE_PERIOD_S,
    rise_s: float = RISE_TIME_S,
    fall_s: float = FALL_TIME_S,
    high_time_s: float = PULSE_HIGH_TIME_S,
) -> complex:
    """
    Complex RMS sine coefficient of one symmetric bipolar trapezoid.

    At integer multiples of 1/T this is the exact Fourier-series line.
    At other frequencies it is the continuous one-period transform envelope.
    """
    angular_frequency = 2.0 * math.pi * frequency_hz
    t0 = 0.0
    t1 = rise_s
    t2 = t1 + high_time_s
    t3 = t2 + fall_s
    t4 = period_s

    coefficient = 0j
    coefficient += _integral_linear_times_exponential(
        t0, t1, -half_amplitude_a, +half_amplitude_a, angular_frequency, period_s
    )
    coefficient += _integral_linear_times_exponential(
        t1, t2, +half_amplitude_a, +half_amplitude_a, angular_frequency, period_s
    )
    coefficient += _integral_linear_times_exponential(
        t2, t3, +half_amplitude_a, -half_amplitude_a, angular_frequency, period_s
    )
    coefficient += _integral_linear_times_exponential(
        t3, t4, -half_amplitude_a, -half_amplitude_a, angular_frequency, period_s
    )
    return math.sqrt(2.0) * coefficient


def current_to_dbua(current_rms_a: complex) -> float:
    magnitude = max(abs(current_rms_a), 1e-30)
    return 20.0 * math.log10(magnitude / 1e-6)


def ce03_limit_dbua(frequency_hz: float) -> float:
    """Piecewise approximation used in the preceding CE03 evaluation.

    CE03 is evaluated from 15 kHz; below that frequency NaN is returned.
    """
    if frequency_hz < CE03_MIN_HZ:
        return float("nan")
    frequency_mhz = frequency_hz / 1e6
    return max(20.0, 30.0 - 30.0 * math.log10(frequency_mhz))


def analyze_frequency(circuit: LinearCircuit, frequency_hz: float) -> Dict[str, object]:
    idm_rms = pulse_sine_rms_coefficient(frequency_hz, IDM_HALF_AMPLITUDE_A)
    icm_each_rms = pulse_sine_rms_coefficient(
        frequency_hz, ICM_EACH_HALF_AMPLITUDE_A
    )
    solution = circuit.solve(
        frequency_hz,
        {"I1": idm_rms, "I2": icm_each_rms, "I3": icm_each_rms},
    )
    hot_current = circuit.branch_current(solution, "VPROBE_HOT")
    rtn_current = circuit.branch_current(solution, "VPROBE_RTN")
    hot_dbua = current_to_dbua(hot_current)
    rtn_dbua = current_to_dbua(rtn_current)
    worst_dbua = max(hot_dbua, rtn_dbua)
    limit_dbua = ce03_limit_dbua(frequency_hz)
    return {
        "frequency_Hz": frequency_hz,
        "Idm_source_rms_A": abs(idm_rms),
        "Idm_source_phase_deg": math.degrees(np.angle(idm_rms)),
        "Icm_each_source_rms_A": abs(icm_each_rms),
        "Icm_each_source_phase_deg": math.degrees(np.angle(icm_each_rms)),
        "Ihot_rms_A": abs(hot_current),
        "Ihot_phase_deg": math.degrees(np.angle(hot_current)),
        "Irtn_rms_A": abs(rtn_current),
        "Irtn_phase_deg": math.degrees(np.angle(rtn_current)),
        "Ihot_dBuA": hot_dbua,
        "Irtn_dBuA": rtn_dbua,
        "worst_dBuA": worst_dbua,
        "CE03_limit_dBuA": limit_dbua,
        "margin_dB": limit_dbua - worst_dbua if math.isfinite(limit_dbua) else float("nan"),
    }


def choose_japanese_font() -> None:
    installed = {font.name for font in font_manager.fontManager.ttflist}
    for candidate in (
        "Noto Sans CJK JP",
        "Noto Sans JP",
        "IPAexGothic",
        "IPAGothic",
        "Yu Gothic",
        "Meiryo",
    ):
        if candidate in installed:
            plt.rcParams["font.family"] = candidate
            break
    plt.rcParams["axes.unicode_minus"] = False


# -----------------------------------------------------------------------------
# Main analysis
# -----------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "net",
        type=Path,
        nargs="?",
        default=None,
        help="LTspice ExpressPCB .net file (省略時はファイル選択ダイアログ)",
    )
    parser.add_argument("--asc", type=Path, default=None, help="matching LTspice .asc file")
    parser.add_argument(
        "--outdir", type=Path, default=Path("ce03_output"), help="output directory"
    )
    args = parser.parse_args()

    # VS Code の「Python ファイルを実行」ボタンではコマンドライン引数が
    # 渡されないため、net が省略されたときはファイル選択ダイアログを開く。
    if args.net is None:
        try:
            import tkinter as tk
            from tkinter import filedialog

            root = tk.Tk()
            root.withdraw()
            selected = filedialog.askopenfilename(
                title="解析するLTspiceネットリストを選択してください",
                filetypes=[
                    ("LTspice netlist", "*.net"),
                    ("All files", "*.*"),
                ],
            )
            root.destroy()
        except Exception as exc:
            parser.error(
                "netファイルが指定されていません。ターミナルからnetファイルを指定するか、"
                f"Tkinterを使用可能にしてください。詳細: {exc}"
            )

        if not selected:
            print("ファイル選択がキャンセルされました。")
            return
        args.net = Path(selected)

    args.net = args.net.expanduser().resolve()
    if not args.net.exists():
        parser.error(f"netファイルが見つかりません: {args.net}")

    # --asc を省略した場合は、netと同名のascを自動検出する。
    if args.asc is None:
        matching_asc = args.net.with_suffix(".asc")
        if matching_asc.exists():
            args.asc = matching_asc
    else:
        args.asc = args.asc.expanduser().resolve()
        if not args.asc.exists():
            parser.error(f"ascファイルが見つかりません: {args.asc}")

    # --outdir を省略したときは、netファイルと同じフォルダ内へ出力する。
    if args.outdir == Path("ce03_output"):
        args.outdir = args.net.parent / "ce03_output"
    else:
        args.outdir = args.outdir.expanduser().resolve()
    args.outdir.mkdir(parents=True, exist_ok=True)

    print(f"NET : {args.net}")
    print(f"ASC : {args.asc if args.asc is not None else '未指定（既定値を使用）'}")
    print(f"出力: {args.outdir}")

    # Read .param directives from both files.  This supports component values
    # such as R18={RD18} as well as dependent formulas such as RL=acrms**2/PIN.
    parameters = resolve_parameters([args.net, args.asc])
    print("主要パラメータ:")
    for key in ("rd18", "rl", "acrms", "fsw", "idm_pp", "icm_pp"):
        if key in parameters:
            print(f"  {key} = {parameters[key]:.12g}")

    parts = parse_expresspcb_netlist(args.net, parameters)
    couplings, inductor_rser = parse_asc_metadata(args.asc)
    circuit = LinearCircuit(parts, couplings, inductor_rser)

    # Exact PULSE Fourier-series lines: 125 kHz through 50 MHz.
    max_harmonic = int(math.floor(FREQ_MAX_HZ / FSW_HZ))
    harmonic_rows: List[Dict[str, object]] = []
    r18_switching_power_w = 0.0
    r18_value = circuit.by_name["R18"].value
    assert r18_value is not None

    for harmonic in range(1, max_harmonic + 1):
        frequency_hz = harmonic * FSW_HZ
        row = analyze_frequency(circuit, frequency_hz)
        row["harmonic"] = harmonic
        harmonic_rows.append(row)

        idm_rms = pulse_sine_rms_coefficient(frequency_hz, IDM_HALF_AMPLITUDE_A)
        icm_each_rms = pulse_sine_rms_coefficient(
            frequency_hz, ICM_EACH_HALF_AMPLITUDE_A
        )
        solution = circuit.solve(
            frequency_hz,
            {"I1": idm_rms, "I2": icm_each_rms, "I3": icm_each_rms},
        )
        r18_current = circuit.resistor_current(solution, "R18")
        r18_switching_power_w += abs(r18_current) ** 2 * r18_value

    harmonic_df = pd.DataFrame(harmonic_rows)
    harmonic_columns = ["harmonic"] + [
        column for column in harmonic_df.columns if column != "harmonic"
    ]
    harmonic_df = harmonic_df[harmonic_columns]
    harmonic_path = args.outdir / "ce03_full_harmonics.csv"
    harmonic_df.to_csv(harmonic_path, index=False, encoding="utf-8-sig")

    # Continuous one-period-transform envelope from 10 kHz to 50 MHz.
    decades = math.log10(FREQ_MAX_HZ) - math.log10(FREQ_MIN_HZ)
    continuous_count = int(math.ceil(decades * CONTINUOUS_POINTS_PER_DECADE)) + 1
    continuous_frequencies = np.logspace(
        math.log10(FREQ_MIN_HZ), math.log10(FREQ_MAX_HZ), continuous_count
    )
    continuous_rows = [analyze_frequency(circuit, float(f)) for f in continuous_frequencies]
    continuous_df = pd.DataFrame(continuous_rows)
    continuous_path = args.outdir / "ce03_continuous_envelope.csv"
    continuous_df.to_csv(continuous_path, index=False, encoding="utf-8-sig")

    # R18 power at 400 Hz plus all exact switching harmonics.
    mains_solution = circuit.solve(AC_FREQUENCY_HZ, mains_voltage_rms=AC_RMS_V)
    r18_400_current = circuit.resistor_current(mains_solution, "R18")
    r18_400_power_w = abs(r18_400_current) ** 2 * r18_value
    r18_total_power_w = r18_400_power_w + r18_switching_power_w
    power_df = pd.DataFrame(
        [
            {
                "R18_ohm": r18_value,
                "I_R18_400Hz_rms_A": abs(r18_400_current),
                "P_R18_400Hz_W": r18_400_power_w,
                "P_R18_switching_harmonics_W": r18_switching_power_w,
                "P_R18_total_W": r18_total_power_w,
            }
        ]
    )
    power_path = args.outdir / "r18_power_summary.csv"
    power_df.to_csv(power_path, index=False, encoding="utf-8-sig")

    # Plot 1: continuous envelope + all exact harmonics + CE03 limit.
    choose_japanese_font()
    figure = plt.figure(figsize=(12, 7), dpi=180)
    frequencies = continuous_df["frequency_Hz"].to_numpy()
    plt.semilogx(
        frequencies,
        continuous_df["CE03_limit_dBuA"].to_numpy(),
        linewidth=2.0,
        label="MIL-STD-461C CE03 限度線（15 kHz～50 MHz）",
    )
    plt.semilogx(
        frequencies,
        continuous_df["worst_dBuA"].to_numpy(),
        linewidth=1.2,
        label="連続包絡線（非高調波点は参考）",
    )
    plt.scatter(
        harmonic_df["frequency_Hz"].to_numpy(),
        harmonic_df["worst_dBuA"].to_numpy(),
        s=8,
        label="PULSEの全高調波（125 kHz刻み）",
    )

    worst_index = harmonic_df["margin_dB"].idxmin()
    worst = harmonic_df.loc[worst_index]
    plt.annotate(
        f"最悪点 {worst['frequency_Hz']/1e3:.0f} kHz\n"
        f"{worst['worst_dBuA']:.2f} dBμA\n"
        f"余裕 +{worst['margin_dB']:.2f} dB",
        xy=(worst["frequency_Hz"], worst["worst_dBuA"]),
        xytext=(20, -5),
        textcoords="offset points",
        arrowprops={"arrowstyle": "->"},
    )

    plt.xlim(FREQ_MIN_HZ, FREQ_MAX_HZ)
    plt.ylim(-80, 90)
    plt.grid(True, which="both", alpha=0.35)
    plt.xlabel("周波数 [Hz]")
    plt.ylabel("伝導エミッション [dBμA]")
    plt.title("MIL-STD-461C CE03 限度線と計算結果（10 kHz～50 MHz）")
    plt.legend(loc="best")
    conditions = (
        "条件: C5=0.33 μF, R18=100 Ω, 既存3 mH CMC + 追加4.7 mH CMC\n"
        "Idm_pp=1 A, Icm_pp=20 mA, fsw=125 kHz\n"
        "注: 周期PULSEの実スペクトルは125 kHzの整数倍にのみ存在"
    )
    plt.text(
        0.015,
        0.025,
        conditions,
        transform=plt.gca().transAxes,
        fontsize=9,
        verticalalignment="bottom",
        bbox={"boxstyle": "round", "facecolor": "white", "alpha": 0.85},
    )
    figure.tight_layout()
    envelope_plot_path = args.outdir / "ce03_full_frequency_envelope.png"
    figure.savefig(envelope_plot_path, bbox_inches="tight")
    plt.close(figure)

    # Plot 2: exact physical spectrum only (all 400 Fourier-series lines).
    figure = plt.figure(figsize=(12, 7), dpi=180)
    plt.semilogx(
        frequencies,
        continuous_df["CE03_limit_dBuA"].to_numpy(),
        linewidth=2.0,
        label="MIL-STD-461C CE03 限度線（15 kHz～50 MHz）",
    )
    plt.scatter(
        harmonic_df["frequency_Hz"].to_numpy(),
        harmonic_df["worst_dBuA"].to_numpy(),
        s=10,
        label="PULSEの全高調波（400点）",
    )
    plt.annotate(
        f"最悪点 {worst['frequency_Hz']/1e3:.0f} kHz\n"
        f"{worst['worst_dBuA']:.2f} dBμA\n"
        f"余裕 +{worst['margin_dB']:.2f} dB",
        xy=(worst["frequency_Hz"], worst["worst_dBuA"]),
        xytext=(25, -10),
        textcoords="offset points",
        arrowprops={"arrowstyle": "->"},
    )
    plt.xlim(FREQ_MIN_HZ, FREQ_MAX_HZ)
    plt.ylim(-80, 90)
    plt.grid(True, which="both", alpha=0.35)
    plt.xlabel("周波数 [Hz]")
    plt.ylabel("伝導エミッション [dBμA]")
    plt.title("MIL-STD-461C CE03：PULSE全高調波（125 kHz～50 MHz）")
    plt.legend(loc="best")
    plt.text(
        0.015,
        0.025,
        "10 kHz～125 kHz未満には、今回の理想周期PULSEによるスペクトル線はありません。\n"
        "偶数次高調波は対称PULSEのため理論上ほぼゼロです。",
        transform=plt.gca().transAxes,
        fontsize=9,
        verticalalignment="bottom",
        bbox={"boxstyle": "round", "facecolor": "white", "alpha": 0.85},
    )
    figure.tight_layout()
    exact_plot_path = args.outdir / "ce03_exact_400_harmonics.png"
    figure.savefig(exact_plot_path, bbox_inches="tight")
    plt.close(figure)
    # Human-readable summary.
    summary_path = args.outdir / "summary.txt"
    summary_path.write_text(
        "\n".join(
            [
                "MIL-STD-461C CE03 calculation summary",
                f"Netlist: {args.net}",
                f"ASC: {args.asc}",
                f"Load resistance RL: {parameters['rl']:.6f} ohm",
                f"Harmonics evaluated: 1 to {max_harmonic}",
                f"Worst frequency: {worst['frequency_Hz']:.0f} Hz",
                f"Worst result: {worst['worst_dBuA']:.6f} dBuA",
                f"CE03 limit: {worst['CE03_limit_dBuA']:.6f} dBuA",
                f"Margin: {worst['margin_dB']:.6f} dB",
                f"R18 400 Hz power: {r18_400_power_w:.9f} W",
                f"R18 switching-harmonic power: {r18_switching_power_w:.9f} W",
                f"R18 total power: {r18_total_power_w:.9f} W",
            ]
        ),
        encoding="utf-8",
    )

    print(f"Created: {harmonic_path}")
    print(f"Created: {continuous_path}")
    print(f"Created: {envelope_plot_path}")
    print(f"Created: {exact_plot_path}")
    print(f"Created: {power_path}")
    print(f"Created: {summary_path}")
    print(
        f"Worst point: {worst['frequency_Hz']/1e3:.0f} kHz, "
        f"{worst['worst_dBuA']:.2f} dBµA, margin +{worst['margin_dB']:.2f} dB"
    )
    print(f"R18 total power: {r18_total_power_w:.6f} W")


if __name__ == "__main__":
    main()

CE03ネットリスト解析 Python v3
================================

修正内容
--------
v2では、部品値が {RD18} のようなLTspiceパラメータ表記の場合、
RL以外のパラメータを解析側へ渡していなかったため、

  KeyError: No value supplied for parameter 'RD18'

が発生しました。

v3では、NET/ASC内の .param 文を自動読込みし、依存式も順番に評価します。
例:

  .param RD18=100
  .param RL=acrms**2/PIN PIN=POUT/(PF*AF*DF)

R18={RD18} の形式でも実行できます。
現在設計用の安全な予備値として RD18=100 ohm も内蔵しています。

実行方法
--------
1. ce03_netlist_analysis_v3.py と対象の .net/.asc を同じフォルダに置く。
2. VS Codeで ce03_netlist_analysis_v3.py を開く。
3. 右上の実行ボタンを押す。
4. ファイル選択画面で .net を選ぶ。
5. 同名の .asc があれば自動的に読み込まれる。
6. 同じフォルダの ce03_output に結果が出力される。

ターミナルからの例:

  py ce03_netlist_analysis_v3.py "461C_FILTER_20260719(2).net" --asc "461C_FILTER_20260719(2).asc" --outdir ce03_output

必要パッケージ:

  py -m pip install numpy pandas matplotlib

確認済み結果
------------
修正版回路に対して:
  最悪点: 125 kHz
  計算値: 50.472720 dBµA
  CE03限度: 57.092700 dBµA
  余裕: +6.619979 dB
  R18合計発熱: 0.208475911 W
